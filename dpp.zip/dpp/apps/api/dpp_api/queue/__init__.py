"""SQS-compatible queue client."""

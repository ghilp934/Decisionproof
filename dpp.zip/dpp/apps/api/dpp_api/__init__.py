"""DPP API - Decision Pack Platform API Service."""

__version__ = "0.4.2.2"

"""S3-compatible storage client."""

from dpp_api.storage.s3_client import S3Client, get_s3_client

__all__ = ["S3Client", "get_s3_client"]
